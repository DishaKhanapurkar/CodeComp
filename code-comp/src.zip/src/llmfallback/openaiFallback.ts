import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function estimateComplexityWithLLM(
  functionCode: string
): Promise<string> {
  const prompt = `
Analyze the following JavaScript/TypeScript function and return ONLY
its time complexity in Big-O notation.

Code:
${functionCode}
`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    temperature: 0,
  });

  return response.choices[0].message.content?.trim() || "O(?)";
}
